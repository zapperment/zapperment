===========================================
Ableton Live Control Surface for Zapperment
===========================================

Version 0.3.0

To control Ableton Live with Zapperment, move the directory "Zapperment" in
this zip file over to your MIDI Remote Scripts directory (a subdirectory of
your Live installation).

For more detailed instructions, see Ableton's knowledge base:

https://help.ableton.com/hc/articles/209072009-Installing-Third-Party-Control-Surfaces

